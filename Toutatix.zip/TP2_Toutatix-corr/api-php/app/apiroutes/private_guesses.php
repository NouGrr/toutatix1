<?php

require_once __DIR__ . '/../auth/JwtHandler.php';
require_once __DIR__ . '/../auth/Exceptions.php';
require_once __DIR__ . '/../db/DBConnection.php';
require_once __DIR__ . '/../utils/AutoDeleteStream.php';

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Nyholm\Psr7\Stream;


$app->get('/api/guesses', function(Request $request, Response $response) {
    // Do a try-catch which tries to get user info from token
    try {
        $userData = get_token_infos($request);

        try {
            // From DB, get all guesses and return JSON array with all info
            $sql = "SELECT * FROM guesses";
            $dbconn = new DB\DBConnection();
            $db = $dbconn->connect();
            $stmt = $db->query($sql);
            $guesses = $stmt->fetchAll(PDO::FETCH_OBJ);
            $db = null;
            
            foreach ($guesses as $guess) {
                if (isset($guess->id)) {
                    $dateTime = new DateTime("@".($guess->id / 1000));
                    $dateTime->setTimezone(new DateTimeZone('Europe/Paris')); // UTC+2 timezone
                    $guess->date = $dateTime->format('r');
                }
            }

            // Prepare the response body
            $responsebody = [
                "success" => true,
                "data" => $guesses
            ];

            // Return the response with status 200
            $response->getBody()->write(json_encode($responsebody));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(200);

        } catch (PDOException $e) {
            // Response: 500 - PDO Error (DB)
            $response->getBody()->write('{"success": false, "message": "' . $e->getMessage() . '"}');
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    } catch (Auth\UnauthenticatedException $e) {
        // Response: 401 - Unauthenticated Exception - Authentication Error
        $response->getBody()->write('{"success": false, "message": "' . $e->getMessage() . '"}');
        return $response->withHeader('Content-Type', 'application/json')->withStatus(401);
    } catch (Exception $e) {
        // Response: 500 - General Error
        $response->getBody()->write('{"error": {"msg": "' . $e->getMessage() . '"}}');
        return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
    }
});


$app->get('/api/guesses/images', function(Request $request, Response $response) {
    // Retrieve upload directory from config
    $directory = $this->get('upload_directory');

    // Do a try-catch which tries to get user info from token
    try {
        $userData = get_token_infos($request);

        try {
            // Browse History entries from DB (table guesses)
            $sql = "SELECT * FROM guesses WHERE win IS NOT NULL";
            $dbconn = new DB\DBConnection();
            $db = $dbconn->connect();
            $stmt = $db->query($sql);
            $guesses = $stmt->fetchAll(PDO::FETCH_OBJ);
            $db = null;

            // Create a new ZipArchive
            $zip = new ZipArchive();
            $zipFileName = $directory . DIRECTORY_SEPARATOR . 'guesses_images.zip';

            // Open the zip file for writing
            if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
                throw new Exception("Cannot open <$zipFileName>\n");
            }

            // Add each image to the zip file
            foreach ($guesses as $guess) {
                $character = $guess->guess; // Assuming guess is either 'Asterix' or 'Obelix'
                $imagepath = $guess->imagepath;

                if ($guess->win == 1) {
                    // Image with win == 1 goes to GoodPred of the found category
                    $entryname = sprintf('%s/GoodPred/%s', $character, basename($guess->imagepath));
                } elseif ($guess->win == -1) {
                    // Image with win == -1 goes to BadPred of the opposite category
                    $oppositeCharacter = ($character == 'Asterix') ? 'Obelix' : 'Asterix';
                    $entryname = sprintf('%s/BadPred/%s', $oppositeCharacter, basename($guess->imagepath));
                } else {
                    // Skip images with win == 0
                    continue;
                }

                if (file_exists($imagepath)) {
                    $zip->addFile($imagepath, $entryname);
                }
            }


            // Close the zip file
            $zip->close();

            // Create the stream for the zip file
            $stream = Stream::create(fopen($zipFileName, 'rb'));

            // Return the response containing the zip file as stream
            return $response->withHeader('Content-Type', 'application/zip')
                ->withHeader('Content-Disposition', 'attachment; filename=' . basename($zipFileName))
                ->withHeader('Content-Length', (string) filesize($zipFileName))
                ->withBody($stream);

        } catch (PDOException $e) {
            // Response: 500 - PDO Error (DB)
            $response->getBody()->write('{"success": false, "message": "' . $e->getMessage() . '"}');
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        } catch (Exception $e) {
            // Response: 500 - General Error
            $response->getBody()->write('{"success": false, "message": "' . $e->getMessage() . '"}');
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    } catch (Auth\UnauthenticatedException $e) {
        // Response: 401 - Unauthenticated Exception - Authentication Error
        $response->getBody()->write('{"success": false, "message": "' . $e->getMessage() . '"}');
        return $response->withHeader('Content-Type', 'application/json')->withStatus(401);
    } catch (Exception $e) {
        // Response: 500 - General Error
        $response->getBody()->write('{"error": {"msg": "' . $e->getMessage() . '"}}');
        return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
    }
});


$app->delete('/api/guesses', function (Request $request, Response $response) {
    // Retrieve upload directory from config
    $directory = $this->get('upload_directory');
    
    // Do a try-catch which tries to get user info from token
    try {
        $userData = get_token_infos($request);

        // Check if the user is an admin
        if ($userData->admin === 1) {
            try {
                // Delete all entries from the database
                $sql = "DELETE FROM guesses";
                $dbconn = new DB\DBConnection();
                $db = $dbconn->connect();
                $stmt = $db->prepare($sql);
                $stmt->execute();
                
                // Delete all files from the upload directory
                $files = glob($directory . '/*'); // Get all file names
                foreach ($files as $file) {
                    if (is_file($file)) {
                        unlink($file); // Delete file
                    }
                }

                $response->getBody()->write(json_encode(array(
                    "success" => true,
                    "message" => "All guesses deleted!"
                )));
                return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
            } catch (PDOException $e) {
                // Response: 500 - PDO Error (DB)
                $response->getBody()->write(json_encode(array(
                    "success" => false,
                    "message" => $e->getMessage()
                )));
                return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
            }
        } else {
            $response->getBody()->write(json_encode(array(
                "success" => false,
                "message" => "Access Denied: Not Allowed Operation with user's privilege"
            )));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(403);
        }
    } catch (Auth\UnauthenticatedException $e) {
        // Response: 401 - Unauthenticated Exception - Authentication Error
        $response->getBody()->write(json_encode(array(
            "success" => false,
            "message" => $e->getMessage()
        )));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(401);
    } catch (Exception $e) {
        // Response: 500 - General Error
        $response->getBody()->write(json_encode(array(
            "error" => array(
                "msg" => $e->getMessage()
            )
        )));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
    }
});



/**
 * Function which parse token, decode user infos from this token and Throws UnauthenticatedException if Autthentication Issue.
 * 
 * The UnauthenticatedException must be catched in the caller and should result to a 401 Http Error
 */
function get_token_infos(Request $request){


    if ($request->hasHeader('Authorization')) {
        list($token) = sscanf($request->getHeaderLine('Authorization'), 'Bearer %s');

        $jwt = new Auth\JwtHandler();
        try
        {
            $data = $jwt->_jwt_decode_data($token);

            return $data;
        }
        catch (Exception $e)
        {
            throw new Auth\UnauthenticatedException("Invalid token : ". $e->getMessage());
        }
        
        
    }
    else{
        throw new Auth\UnauthenticatedException("Unable to find Authorization Header");
    }
}


?>