<?php
require_once __DIR__ . '/../auth/JwtHandler.php';
require_once __DIR__ . '/../db/DBConnection.php';
require_once __DIR__ . '/../utils/AutoDeleteStream.php';

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

// Vérifie si le formulaire a été soumis et le fichier a été téléchargé avec succès
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
    // Chemin temporaire du fichier téléchargé
    $tmp_name = $_FILES['image_file']['tmp_name'];

    // Vérifie si c'est bien un fichier image
    $mime_type = mime_content_type($tmp_name);
    if (strpos($mime_type, 'image/') === 0) {
        try {
            // Envoyer le fichier à l'API Node.js pour prédiction
            $client = new GuzzleHttp\Client(['base_uri' => 'http://node:3000/api/']);
            $response = $client->request('POST', 'guesses', [
                'multipart' => [
                    [
                        'name'     => 'guessimage',
                        'contents' => fopen($tmp_name, 'r'),
                        'filename' => $_FILES['image_file']['name']
                    ]
                ]
            ]);

            // Vérifier si la réponse de l'API est OK
            if ($response->getStatusCode() == 201 || $response->getStatusCode() == 200) {
                $api_response = json_decode($response->getBody());

                // Afficher la prédiction de l'API
                if (isset($api_response->guess)) {
                    echo json_encode(['success' => true, 'guess' => $api_response->guess]);
                    exit; // Terminer l'exécution après l'affichage de la réponse JSON
                } else {
                    echo json_encode(['success' => false, 'message' => 'No prediction received from API.']);
                    exit; // Terminer l'exécution après l'affichage de la réponse JSON
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Error from API: ' . $response->getReasonPhrase()]);
                exit; // Terminer l'exécution après l'affichage de la réponse JSON
            }
        } catch (RequestException $e) {
            echo json_encode(['success' => false, 'message' => 'API Request Exception: ' . $e->getMessage()]);
            exit; // Terminer l'exécution après l'affichage de la réponse JSON
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Uploaded file is not an image.']);
        exit; // Terminer l'exécution après l'affichage de la réponse JSON
    }
}
?>
