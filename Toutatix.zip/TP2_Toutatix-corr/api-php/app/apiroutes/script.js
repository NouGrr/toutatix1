document.addEventListener('DOMContentLoaded', function() {
    const signinForm = document.getElementById('signin-form');
    const message = document.getElementById('message');

    signinForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(signinForm);

        fetch('/api/login', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                localStorage.setItem('token', data.token); // Stockage du jeton dans le localStorage
                window.location.href = 'home.html'; // Redirection vers la page d'accueil après connexion réussie
            } else {
                message.textContent = data.message; // Affichage du message d'erreur en cas d'échec de la connexion
            }
        })
        .catch(error => {
            console.error('Error:', error);
            message.textContent = 'An error occurred. Please try again later.'; // Message d'erreur générique en cas d'échec de la requête
        });
    });
});
